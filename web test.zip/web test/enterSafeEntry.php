<html>
<body>

<p id="result"></p>
<!--you are in  <?php echo $_POST["location"]; ?><br>
your name : <?php echo $_POST["name"]; ?> -->

<script>
    var shouldRun = true
    console.log("Now in java script." <?php echo $_POST["location"]; ?> +  <?php echo $_POST["name"]; ?>);
    if(<?php echo $_POST["location"]; ?> === ""){
        shouldRun = false;
    }
    if(<?php echo $_POST["name"]; ?> === ""){
        shouldRun = false;
    }

    if(shouldRun === true){
        document.getElementById("result").innerHTML = you are in <?php echo $_POST["location"]; ?><br>your name is <?php echo $_POST["name"]; ?>;
    }else{
        document.getElementById("result").innerHTML= dont give null responses
    }

</script>
</body>
</html>